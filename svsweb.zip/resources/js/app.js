require('./bootstrap');

require('alpinejs');

require('./custom');

require('./vtk/viewer');
