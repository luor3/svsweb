        <?php $__env->startSection('title'); ?> <?php echo e($page['title']); ?> <?php echo $__env->yieldContent('title'); ?> <?php $__env->stopSection(); ?>
        <?php $__env->startSection('description'); ?> <?php echo e($page['description']); ?> <?php echo $__env->yieldContent('description'); ?> <?php $__env->stopSection(); ?>
        <?php $__env->startSection('keywords'); ?> <?php echo e($page['keywords']); ?> <?php echo $__env->yieldContent('keywords'); ?> <?php $__env->stopSection(); ?>
        <?php $__env->startSection('facebook_admins'); ?> <?php echo e($app->facebookadmins); ?> <?php echo $__env->yieldContent('facebook_admins'); ?> <?php $__env->stopSection(); ?>
        <?php $__env->startSection('facebook_page_id'); ?> <?php echo e($app->facebookpageid); ?> <?php echo $__env->yieldContent('facebook_page_id'); ?> <?php $__env->stopSection(); ?>
        <?php $__env->startSection('twitter_id'); ?> <?php echo e($app->twitterpageid); ?> <?php echo $__env->yieldContent('twitter_id'); ?> <?php $__env->stopSection(); ?>
        <?php $__env->startSection('author'); ?> <?php echo e($app->author); ?> <?php echo $__env->yieldContent('author'); ?> <?php $__env->stopSection(); ?>
        
        <title><?php echo $__env->yieldContent('title'); ?></title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="viewport' content='width=device-width, initial-scale=1, minimum-scale=1" />
        <meta name="description" content="<?php echo $__env->yieldContent('description'); ?>"/>
        <meta name="robots" content="All" />
        <meta name="robots" content="index, follow" />
        <meta name="keywords" content="<?php echo $__env->yieldContent('keywords'); ?>" />
        <meta name="rating" content="General" />
        <meta name="dcterms.title" content="<?php echo $__env->yieldContent('title'); ?>" />
        <meta name="dcterms.contributor" content="<?php echo $__env->yieldContent('author'); ?>" />
        <meta name="dcterms.creator" content="<?php echo $__env->yieldContent('author'); ?>" />
        <meta name="dcterms.publisher" content="<?php echo $__env->yieldContent('author'); ?>" />
        <meta name="dcterms.description" content="<?php echo $__env->yieldContent('description'); ?>" />
        <meta name="dcterms.rights" content="2020 - 2030" />
        <meta property="og:type" content="website" />
        <meta property="og:locale" content="en_US" />
        <meta property="og:title" content="<?php echo $__env->yieldContent('title'); ?>" />
        <meta property="og:url" content="<?php echo e(\Request::fullUrl()); ?>" />
        <meta property="og:site_name" content="<?php echo $__env->yieldContent('author'); ?>" />
        <meta property="og:title" content="<?php echo $__env->yieldContent('title'); ?>" />
        <meta property="og:description" content="<?php echo $__env->yieldContent('description'); ?>" />
        <meta property="twitter:title" content="<?php echo $__env->yieldContent('title'); ?>" />
        <meta property="twitter:description" content="<?php echo $__env->yieldContent('description'); ?>" />
        <meta property="og:image" content="<?php echo e(URL::asset('images/favicon.png')); ?>"/>
        <meta property="og:image:type" content="image/png"/>
        <meta property="og:image:width" content="200"/>
        <meta property="og:image:height" content="200"/>
        <meta property="fb:admins" content="<?php echo $__env->yieldContent('facebook_admins'); ?>" />
        <meta property="fb:page_id" content="<?php echo $__env->yieldContent('facebook_page_id'); ?>"/>
        <meta property="twitter_id" content="<?php echo $__env->yieldContent('twitter_id'); ?>"/>
        <meta name="_token" content="<?php echo csrf_token(); ?>" />
        <link href="<?php echo e(\Request::fullUrl()); ?>" rel="canonical">
        
        
    <?php /**PATH C:\Program Files\Ampps\www\svsweb\resources\views/partials/metas.blade.php ENDPATH**/ ?>