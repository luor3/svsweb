<?php if (isset($component)) { $__componentOriginalc3251b308c33b100480ddc8862d4f9c79f6df015 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\GuestLayout::class, []); ?>
<?php $component->withName('guest-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
    <?php $__env->startPush('metas'); ?>
        <?php echo $__env->make('partials.metas', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php $__env->stopPush(); ?>
    
    <div>
        <?php echo $__env->make('partials.site-navigation', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <div class="bg-indigo-900 md:overflow-hidden">
            <div class="px-4 py-10 md:py-0">
                <div class="md:max-w-6xl md:mx-auto">
                    <div class="md:flex md:flex-wrap">
                        <div class="md:w-1/1 text-center md:text-left md:pt-6">
                            <h2 class="font-bold text-white text-2xl md:text-5xl leading-tight mb-4">
                                <?php echo e($app->author); ?>

                            </h2>

                            <p class="text-indigo-200 md:text-xl md:pr-48">
                                <?php echo e($app->description); ?>

                            </p>

                            <a href="<?php echo e(url('/demos')); ?>" class="mt-6 mb-12 md:mb-0 md:mt-10 inline-block py-3 px-8 text-white bg-red-500 hover:bg-red-600 rounded-lg shadow">Get Started!</a>
                        </div>
                    </div>
                </div>
            </div>
            <svg class="fill-current text-white hidden md:block" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1440 320">
            <path fill-opacity="1" d="M0,224L1440,32L1440,320L0,320Z"></path>
            </svg>
        </div>

        <p class="text-center p-4 text-gray-600 pt-20 lg:pt-0">Copyright © <?php echo e(date('Y')); ?> <?php echo e($app->author); ?>. All rights reserved.</p>
    </div>
    
 <?php if (isset($__componentOriginalc3251b308c33b100480ddc8862d4f9c79f6df015)): ?>
<?php $component = $__componentOriginalc3251b308c33b100480ddc8862d4f9c79f6df015; ?>
<?php unset($__componentOriginalc3251b308c33b100480ddc8862d4f9c79f6df015); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?><?php /**PATH C:\Program Files\Ampps\www\svsweb\resources\views/home.blade.php ENDPATH**/ ?>