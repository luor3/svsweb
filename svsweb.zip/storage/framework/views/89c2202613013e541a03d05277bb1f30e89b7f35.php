<div>
    
    <form wire:submit.prevent="generateFile">            
            <div class="p-5 mt-10 w-11/12 bg-blue-100 bg-opacity-75 mx-auto rounded-2xl shadow-2xl">
                <h1 class="font-bold text-2xl mb-4"><?php echo e($inputInfo['name']); ?></h1>
                <div class="my-10 bg-blue-600 h-1"></div>
    
                <div class="grid grid-cols-12 gap-x-4">        
                    <?php $__currentLoopData = $inputInfo['properties']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $property): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="text-center col-span-12 <?php echo e(isset($property['children']) ? 'md:place-self-center' : 'md:col-span-4'); ?>">
                        <?php if( (isset($enableSeq[$key]['main']) && $enableSeq[$key]['main']) || (!isset($enableSeq[$key]['main'])) ): ?> 
                            <div x-data="{ open: false }">
                                <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.label','data' => ['class' => 'lg:h-10 inline-block mt-5 text-gray-700','for' => ''.e($key).'','value' => ''.e($property['title']).'']]); ?>
<?php $component->withName('jet-label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'lg:h-10 inline-block mt-5 text-gray-700','for' => ''.e($key).'','value' => ''.e($property['title']).'']); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
                                <?php if(isset($property['hint'])): ?>
                                    <button type="button" class="w-4 h-4 inline-block" @click="open = ! open">
                                        <svg version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink"
                                            viewBox="0 0 422.686 422.686" style="enable-background:new 0 0 422.686 422.686;" xml:space="preserve">
                                        <g>
                                            <g>
                                                <path style="fill:#010002;" d="M211.343,422.686C94.812,422.686,0,327.882,0,211.343C0,94.812,94.812,0,211.343,0
                                                    s211.343,94.812,211.343,211.343C422.694,327.882,327.882,422.686,211.343,422.686z M211.343,16.257
                                                    c-107.565,0-195.086,87.52-195.086,195.086s87.52,195.086,195.086,195.086c107.574,0,195.086-87.52,195.086-195.086
                                                    S318.917,16.257,211.343,16.257z"/>
                                            </g>
                                            <g>
                                                <g>
                                                    <path style="fill:#010002;" d="M192.85,252.88l-0.569-7.397c-1.707-15.371,3.414-32.149,17.647-49.227
                                                        c12.811-15.078,19.923-26.182,19.923-38.985c0-14.51-9.112-24.182-27.044-24.467c-10.242,0-21.622,3.414-28.735,8.819
                                                        l-6.828-17.924c9.388-6.828,25.605-11.38,40.692-11.38c32.726,0,47.52,20.2,47.52,41.83c0,19.346-10.811,33.295-24.483,49.511
                                                        c-12.51,14.794-17.07,27.312-16.216,41.83l0.284,7.397H192.85V252.88z M186.583,292.718c0-10.526,7.121-17.923,17.078-17.923
                                                        c9.966,0,16.785,7.397,16.785,17.924c0,9.957-6.544,17.639-17.07,17.639C193.419,310.349,186.583,302.667,186.583,292.718z"/>
                                                </g>
                                            </g>
                                        </g>
                                        </svg>
                                    </button>
                                        
                                    <div class="mb-2 h-5 leading-5">
                                        <div :class="{ 'hidden': !open }" class="hidden" x-transition>
                                            <span class="text-red-500">
                                                <?php echo e($property['hint']); ?>

                                            </span> 
                                        </div>
                                    </div>
                                <?php endif; ?>
                            </div>

                            <?php if($property['type'] === "select"): ?>
                                <select
                                    class="w-full border border-transparent disabled:opacity-20 focus:outline-none focus:ring-2 shadow-md focus:ring-blue-300 focus:border-transparent form-select block w-full mt-1 mb-5 rounded-lg"
                                    wire:model="inputValue.<?php echo e($key); ?>.main" id="<?php echo e($key); ?>">
                                    <option value=<?php echo e(null); ?>>Select the Value</option>
                                    <?php $__currentLoopData = $property['options']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($option['value']); ?>"><?php echo e($option['title']); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select> 
                            <?php elseif($property['type'] !== "multiple"): ?>
                                <input
                                    class='w-full bg-white text-gray-700 disabled:opacity-20 shadow-md rounded-lg appearance-none mb-5 py-2 px-3 border border-transparent focus:outline-none focus:ring-2 focus:ring-blue-300 focus:border-transparent'
                                    type="<?php echo e($property['htmlType']); ?>" step="any" wire:model="inputValue.<?php echo e($key); ?>.main" id="<?php echo e($key); ?>" <?php echo e((isset($property['required']) && $property['required'])? "required" : ""); ?>>                      
                            <?php endif; ?>
                            <div class = "h-4">
                                <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.input-error','data' => ['for' => 'inputValue.'.e($key).'.main','class' => 'mt-2']]); ?>
<?php $component->withName('jet-input-error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['for' => 'inputValue.'.e($key).'.main','class' => 'mt-2']); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
                            </div>
    

                            <?php for($i = 0; $i < ((isset($property['children'])) ? ( (isset($repeatNum[$key]['main'])) ? $repeatNum[$key]['main'] : 1) : 0); $i++): ?>
                                <div class="mb-5 shadow-md rounded-lg bg-yellow-50 bg-opacity-25">
                                    <?php $__currentLoopData = $property['children']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cKey => $cProperty): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if( $cProperty['type'] === "linebreak"): ?>
                                            <div></div>
                                            <?php continue; ?>
                                        <?php endif; ?> 
                                        <?php if( (isset($enableSeq[$key][$cKey]) && $enableSeq[$key][$cKey]) || (!isset($enableSeq[$key][$cKey])) ): ?>
                                            <div class="p-2 <?php echo e((isset($cProperty['display'])) ? $cProperty['display'] : ''); ?>">
                                                <?php for($j = 0 ; $j < ((isset($cProperty['_repeat'])) ? $repeatNum[$key]['children'][$i][$cKey] : 1 ) ; $j++): ?>
            
                                                    <div x-data="{ open: false }">
                                                        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.label','data' => ['class' => 'inline-block mt-5 text-gray-700','for' => 'inputValue.'.e($key).'.children.'.e($i).'.'.e($cKey).''.e((isset($cProperty['_repeat']))? '.'.$j : '').'','value' => ''.e($cProperty['title']).'']]); ?>
<?php $component->withName('jet-label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'inline-block mt-5 text-gray-700','for' => 'inputValue.'.e($key).'.children.'.e($i).'.'.e($cKey).''.e((isset($cProperty['_repeat']))? '.'.$j : '').'','value' => ''.e($cProperty['title']).'']); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
                                                        <?php if(isset($cProperty['hint'])): ?>
                                                            <button type="button" class="inline-block w-4 h-4" @click="open = ! open">
                                                                <svg version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink"
                                                                    viewBox="0 0 422.686 422.686" style="enable-background:new 0 0 422.686 422.686;" xml:space="preserve">
                                                                <g>
                                                                    <g>
                                                                        <path style="fill:#010002;" d="M211.343,422.686C94.812,422.686,0,327.882,0,211.343C0,94.812,94.812,0,211.343,0
                                                                            s211.343,94.812,211.343,211.343C422.694,327.882,327.882,422.686,211.343,422.686z M211.343,16.257
                                                                            c-107.565,0-195.086,87.52-195.086,195.086s87.52,195.086,195.086,195.086c107.574,0,195.086-87.52,195.086-195.086
                                                                            S318.917,16.257,211.343,16.257z"/>
                                                                    </g>
                                                                    <g>
                                                                        <g>
                                                                            <path style="fill:#010002;" d="M192.85,252.88l-0.569-7.397c-1.707-15.371,3.414-32.149,17.647-49.227
                                                                                c12.811-15.078,19.923-26.182,19.923-38.985c0-14.51-9.112-24.182-27.044-24.467c-10.242,0-21.622,3.414-28.735,8.819
                                                                                l-6.828-17.924c9.388-6.828,25.605-11.38,40.692-11.38c32.726,0,47.52,20.2,47.52,41.83c0,19.346-10.811,33.295-24.483,49.511
                                                                                c-12.51,14.794-17.07,27.312-16.216,41.83l0.284,7.397H192.85V252.88z M186.583,292.718c0-10.526,7.121-17.923,17.078-17.923
                                                                                c9.966,0,16.785,7.397,16.785,17.924c0,9.957-6.544,17.639-17.07,17.639C193.419,310.349,186.583,302.667,186.583,292.718z"/>
                                                                        </g>
                                                                    </g>
                                                                </g>
                                                                </svg>
                                                            </button>
                                                            <div class="mb-2 h-5 leading-5">
                                                                <div :class="{ 'hidden': !open }" class="hidden" x-transition>
                                                                    <span class="text-red-500">
                                                                        <?php echo e($cProperty['hint']); ?>

                                                                    </span> 
                                                                </div>
                                                            </div>
                                                            
                                                        <?php endif; ?>
                                                    </div>

                                                    <?php if($cProperty['type'] === "select"): ?>
                                                        <select
                                                            class="w-1/2 border border-transparent disabled:opacity-20 focus:outline-none focus:ring-2 shadow-md focus:ring-blue-300 focus:border-transparent form-select block w-full mt-1 mb-5 rounded-lg"
                                                            wire:model="inputValue.<?php echo e($key); ?>.children.<?php echo e($i); ?>.<?php echo e($cKey); ?><?php echo e((isset($cProperty['_repeat']))? '.'.$j : ''); ?>" id="inputValue.<?php echo e($key); ?>.children.<?php echo e($i); ?>.<?php echo e($cKey); ?><?php echo e((isset($cProperty['_repeat']))? '.'.$j : ''); ?>">
                                                            <option value=<?php echo e(null); ?>>Select the Value</option>
                                                            <?php $__currentLoopData = $cProperty['options']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <option value="<?php echo e($option['value']); ?>"><?php echo e($option['title']); ?></option>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        </select> 
                                                    <?php else: ?>
                                                        <input
                                                            class='w-1/2 bg-white text-gray-700 disabled:opacity-20 shadow-md rounded-lg appearance-none mb-5 py-2 px-3 border border-transparent focus:outline-none focus:ring-2 focus:ring-blue-300 focus:border-transparent'
                                                            type="<?php echo e($cProperty['htmlType']); ?>" step="any" wire:model="inputValue.<?php echo e($key); ?>.children.<?php echo e($i); ?>.<?php echo e($cKey); ?><?php echo e((isset($cProperty['_repeat']))? '.'.$j : ''); ?>" id="inputValue.<?php echo e($key); ?>.children.<?php echo e($i); ?>.<?php echo e($cKey); ?><?php echo e((isset($cProperty['_repeat']))? '.'.$j : ''); ?>" <?php echo e((isset($cProperty['required']) && $cProperty['required'])? "required" : ""); ?>>
                                                    <?php endif; ?>
                                                    <div class="h-4">
                                                        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.input-error','data' => ['for' => 'inputValue.'.e($key).'.children.'.e($i).'.'.e($cKey).''.e((isset($cProperty['_repeat']))? '.'.$j : '').'','class' => 'mt-2']]); ?>
<?php $component->withName('jet-input-error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['for' => 'inputValue.'.e($key).'.children.'.e($i).'.'.e($cKey).''.e((isset($cProperty['_repeat']))? '.'.$j : '').'','class' => 'mt-2']); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
                                                    </div>
                                                                                                                                                    
                                                <?php endfor; ?> 
                                            </div>
                                        <?php endif; ?>                                   
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            <?php endfor; ?>
                        <?php endif; ?>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div> 

        <button type="submit" wire:loading.remove class="block mx-auto bg-purple-600 text-white text-base font-semibold mt-5 py-2 px-4 rounded-lg shadow-md hover:bg-purple-700 focus:outline-none focus:ring-2 focus:ring-purple-500 focus:ring-offset-2 focus:ring-offset-purple-200">Generate Input File</button>
    </form>

</div><?php /**PATH C:\Program Files\Ampps\www\svsweb\resources\views/frontend/input-generator.blade.php ENDPATH**/ ?>