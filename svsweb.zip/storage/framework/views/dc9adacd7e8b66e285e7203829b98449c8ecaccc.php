<div>
    <div class="">
        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.label','data' => ['class' => 'mb-2 text-gray-700','for' => 'searchCategory','value' => ''.e(__('Select Demo Category')).'']]); ?>
<?php $component->withName('jet-label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'mb-2 text-gray-700','for' => 'searchCategory','value' => ''.e(__('Select Demo Category')).'']); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
        <select
            class="w-full rounded-md border border-gray-300 shadow-sm px-4 py-2 bg-white text-sm font-medium text-gray-700 hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-gray-100 focus:ring-indigo-500" id="searchCategory"
            wire:model="searchCategory">
                <option value="-1">All</option>
                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option class="text-gray-700 block px-4 py-2 text-sm" value="<?php echo e($key); ?>"><?php echo e($value); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select> 
    </div>
    <?php if(count($demos) == 0): ?>
        <h1 class="mt-10 text-center font-bold uppercase">Sorry. No Demo Available for This Category</h1>
    <?php else: ?>
        <div class="grid grid-cols-12 place-items-center gap-x-9">
            <?php $__currentLoopData = $demos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $demo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>   
                <div class='col-span-12 md:col-span-6 mt-10 mb-32 bg-blue-50 mx-auto rounded-2xl shadow-2xl overflow-hidden w-full'>
                    <div class=''>
                        <?php if(isset($demo->plot_path)): ?>
                            <img class="h-full w-full rounded-lg object-cover transition duration-150 ease-in-out transform hover:scale-125"
                                src=" <?php echo e(asset(Storage::disk('local')->url($demo->plot_path))); ?>"
                                alt="No Image">
                        <?php endif; ?>
                    </div>
                    <div class='relative bg-blue-50 text-center pt-2 text-base'>
                        <h1 class="font-bold uppercase">
                            <?php echo e($demo->name); ?>

                        </h1>
                        <div>
                            <?php echo e($demo->description); ?>

                        </div>

                        <div class="mx-auto">
                            <button class="mt-5 mb-5 py-2 px-4 bg-blue-300 text-white font-semibold rounded-lg shadow-md hover:bg-red-500 focus:outline-none" wire:click="downloadFile( <?php echo e($demo->id); ?> , true)" wire:loading.attr="disabled">
                                Download Input Files
                            </button>

                            <button class="mt-5 mb-5 py-2 px-4 bg-blue-300 text-white font-semibold rounded-lg shadow-md hover:bg-red-500 focus:outline-none" wire:click="downloadFile( <?php echo e($demo->id); ?> , false)" wire:loading.attr="disabled">
                                Download Output Files
                            </button> 
                        </div>

                    </div>
                </div>   
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <div class="mt-3">
            <?php echo e($demos->links()); ?>

        </div>
    <?php endif; ?>
</div>
<?php /**PATH C:\Program Files\Ampps\www\svsweb\resources\views/frontend/show-form.blade.php ENDPATH**/ ?>