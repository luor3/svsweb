<span class='h-6 w-6' wire:click="demoOrder( '<?php echo e($columnName); ?>' )">
    <?php if($currentOrderProperty === $columnName): ?>
        <?php if($currentOrder === 'asc'): ?>                                 
            <svg xmlns="http://www.w3.org/2000/svg" class="inline h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7" />
            </svg>
        <?php elseif($currentOrder === 'desc'): ?>                    
            <svg xmlns="http://www.w3.org/2000/svg" class="inline h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 15l7-7 7 7" />
            </svg>
        <?php elseif($currentOrder === ''): ?>
            <svg xmlns="http://www.w3.org/2000/svg" class="inline h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 9l4-4 4 4m0 6l-4 4-4-4" />
            </svg>

        <?php endif; ?>
    <?php else: ?>                            
        <svg xmlns="http://www.w3.org/2000/svg" class="inline h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 9l4-4 4 4m0 6l-4 4-4-4" />
        </svg>
    <?php endif; ?>
</span>
<?php /**PATH C:\Program Files\Ampps\www\svsweb\resources\views/backend-order-bar.blade.php ENDPATH**/ ?>