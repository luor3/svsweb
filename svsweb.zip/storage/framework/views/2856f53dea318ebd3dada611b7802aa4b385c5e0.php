<?php $attributes = $attributes->exceptProps(['actives']); ?>
<?php foreach (array_filter((['actives']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>

<?php
$classes = ($attributes['active'])
            ? 'block lg:inline-block py-1 md:py-4 text-gray-100 mr-6 font-bold'
            : 'block lg:inline-block py-1 md:py-4 text-gray-400 hover:text-gray-100 mr-6';
?>

<a <?php echo e($attributes->merge(['class' => $classes])); ?>>
    <?php echo e($slot); ?>

</a>
<?php /**PATH C:\Program Files\Ampps\www\svsweb\resources\views/components/site-link.blade.php ENDPATH**/ ?>