<?php if (isset($component)) { $__componentOriginalc3251b308c33b100480ddc8862d4f9c79f6df015 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\GuestLayout::class, []); ?>
<?php $component->withName('guest-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
    <?php $__env->startPush('metas'); ?>
    <?php echo $__env->make('partials.metas', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php $__env->stopPush(); ?>

    <div class="min-h-screen flex flex-col">
        <?php echo $__env->make('partials.site-navigation', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <div class="flex-grow p-8 text-1xl">          
            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('frontend.show-form')->html();
} elseif ($_instance->childHasBeenRendered('AP6EWuE')) {
    $componentId = $_instance->getRenderedChildComponentId('AP6EWuE');
    $componentTag = $_instance->getRenderedChildComponentTagName('AP6EWuE');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('AP6EWuE');
} else {
    $response = \Livewire\Livewire::mount('frontend.show-form');
    $html = $response->html();
    $_instance->logRenderedChild('AP6EWuE', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
        </div>
        <div class="bg-indigo-900 text-gray-400 px-4 py-4 font-normal">
            <p class="text-center">Copyright © <?php echo e(date('Y')); ?> <?php echo e($app->author); ?>. All rights reserved.</p>
        </div>
    </div>

 <?php if (isset($__componentOriginalc3251b308c33b100480ddc8862d4f9c79f6df015)): ?>
<?php $component = $__componentOriginalc3251b308c33b100480ddc8862d4f9c79f6df015; ?>
<?php unset($__componentOriginalc3251b308c33b100480ddc8862d4f9c79f6df015); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?><?php /**PATH C:\Program Files\Ampps\www\svsweb\resources\views/frontdemo.blade.php ENDPATH**/ ?>